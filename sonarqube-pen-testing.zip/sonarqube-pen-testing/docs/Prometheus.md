# Sonarqube integration with Prometheus

Prometheus integration is pending. Placeholder for future documentation.  
Sonarqube does not have built-in support for a ```/metrics``` endpoint for Prometheus integration. A metrics exporter plugin is required.  
For example [https://github.com/dmeiners88/sonarqube-prometheus-exporter](https://github.com/dmeiners88/sonarqube-prometheus-exporter)